# bGMYC
A Stable Version of the 'bGMYC' R Package using R versions above 4.x.x
